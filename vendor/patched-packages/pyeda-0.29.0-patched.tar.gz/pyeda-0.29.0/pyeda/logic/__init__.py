"""
PyEDA Logic
"""

